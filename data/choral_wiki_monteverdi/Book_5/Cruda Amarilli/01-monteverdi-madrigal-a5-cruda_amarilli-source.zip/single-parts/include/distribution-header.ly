    composer = "Claudio Monteverdi (1567-1643)"
    source = \markup { \italic { Il quinto libro de madrigali à 5 voci } (Ricciardo Amadino press, Venice, 1605) }
    style = "Renaissance"
    
    % These are legacy fields for mutopia. Not sure if anyone uses them anymore?
    maintainer = "Allen Garvin"
    maintainerEmail = "aurvondel@gmail.com"
    maintainerWeb = "http://dfwviols.com"
    booktitle = \markup { Set by Allen Garvin (aurvondel@gmail.com) (ver. #(strftime "%Y-%m-%d)" (localtime (current-time))) CC BY-NC 2.5 }
    tagline = #'f
